const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const DB_PATH = path.join(__dirname, '..', 'mock', 'db.json');
function readDB(){ return JSON.parse(fs.readFileSync(DB_PATH)); }
function writeDB(d){ fs.writeFileSync(DB_PATH, JSON.stringify(d,null,2)); }

app.post('/api/send-otp', (req, res) => {
  const { to } = req.body;
  const otp = Math.floor(100000 + Math.random()*900000).toString();
  const db = readDB();
  db.otps.push({ to, otp, createdAt: Date.now() });
  writeDB(db);
  console.log('OTP for', to, otp);
  res.json({ success: true, otp });
});

app.post('/api/verify-otp', (req, res) => {
  const { to, otp } = req.body;
  const db = readDB();
  const found = db.otps.find(o => o.to === to && o.otp === otp);
  if(found) return res.json({ success: true, user: db.captain });
  return res.status(401).json({ success: false, message: 'Invalid OTP' });
});

app.post('/api/create-order', (req, res) => {
  const { amount, currency='INR' } = req.body;
  res.json({ id: 'order_' + Math.floor(Math.random()*1000000), amount, currency });
});

app.listen(5000, ()=> console.log('Demo server running on http://localhost:5000'));
