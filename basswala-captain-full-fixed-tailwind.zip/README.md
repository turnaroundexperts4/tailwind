# Basswala Captain - Full Demo App

## Setup & Run

```bash
npm install
npm run mock:server    # start mock backend
npm run server         # start express demo server
npm run dev            # start frontend
```
