import React, { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import Sidebar from './components/Sidebar'
import Dashboard from './pages/Dashboard'
import Bookings from './pages/Bookings'
import Subscribe from './pages/Subscribe'
import Chatbot from './pages/Chatbot'
import Settings from './pages/Settings'
import Login from './pages/Login'
import OtpVerify from './pages/OtpVerify'

export default function App(){
  const [user, setUser] = useState(null)
  const [dark, setDark] = useState(()=> JSON.parse(localStorage.getItem('bw_dark'))||false)
  useEffect(()=>{ document.documentElement.classList.toggle('dark', dark); localStorage.setItem('bw_dark', JSON.stringify(dark)) }, [dark])

  return (
    <div className="flex min-h-screen">
      {user && <Sidebar dark={dark} setDark={setDark} user={user} setUser={setUser} />}
      <div className="flex-1">
        <Routes>
          <Route path="/" element={<Login setUser={setUser} />} />
          <Route path="/otp" element={<OtpVerify setUser={setUser} />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/bookings" element={<Bookings />} />
          <Route path="/subscribe" element={<Subscribe />} />
          <Route path="/chatbot" element={<Chatbot />} />
          <Route path="/settings" element={<Settings setUser={setUser} />} />
        </Routes>
      </div>
    </div>
  )
}