import React from 'react'
import { Link, useNavigate } from 'react-router-dom'

export default function Sidebar({ dark, setDark, user, setUser }){
  const navigate = useNavigate()
  function logout(){ setUser(null); navigate('/') }
  return (
    <div className="w-64 bg-white dark:bg-slate-900 dark:text-gray-100 min-h-screen p-4 border-r border-gray-200 dark:border-slate-700">
      <div className="mb-6">
        <div className="text-2xl font-semibold">Basswala Captain</div>
        <div className="text-sm text-gray-500 dark:text-gray-300">Welcome, {user?.name}</div>
      </div>
      <nav className="space-y-2">
        <Link to="/dashboard" className="block px-3 py-2 rounded hover:bg-gray-100 dark:hover:bg-slate-800">Dashboard</Link>
        <Link to="/bookings" className="block px-3 py-2 rounded hover:bg-gray-100 dark:hover:bg-slate-800">Bookings</Link>
        <Link to="/subscribe" className="block px-3 py-2 rounded hover:bg-gray-100 dark:hover:bg-slate-800">Subscriptions</Link>
        <Link to="/chatbot" className="block px-3 py-2 rounded hover:bg-gray-100 dark:hover:bg-slate-800">AI Chatbot</Link>
        <Link to="/settings" className="block px-3 py-2 rounded hover:bg-gray-100 dark:hover:bg-slate-800">Settings</Link>
        <div className="mt-6 border-t pt-4">
          <div className="flex items-center justify-between">
            <div className="text-sm">Dark Mode</div>
            <input type="checkbox" checked={dark} onChange={(e)=>setDark(e.target.checked)} />
          </div>
          <button className="mt-4 w-full px-3 py-2 rounded bg-red-500 text-white" onClick={logout}>Logout</button>
        </div>
      </nav>
    </div>
  )
}