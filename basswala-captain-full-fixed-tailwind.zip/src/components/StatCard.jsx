
import React from 'react'

export default function StatCard({ label, value }){
  return (
    <div className="p-3 bg-white dark:bg-slate-900 rounded border dark:border-slate-700">
      <div className="text-sm text-gray-500 dark:text-gray-300">{label}</div>
      <div className="text-2xl font-semibold mt-1">₹{value}</div>
    </div>
  )
}
