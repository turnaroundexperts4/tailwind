
import React, { useRef } from 'react'
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction'

export default function BookingCalendar({ events, onSelectSlot }){
  const calRef = useRef(null)

  function handleDateClick(info){
    onSelectSlot && onSelectSlot({ date: info.dateStr })
  }

  return (
    <div className="bg-white dark:bg-slate-900 p-3 rounded border dark:border-slate-700">
      <FullCalendar
        ref={calRef}
        plugins={[ dayGridPlugin, interactionPlugin ]}
        initialView="dayGridMonth"
        events={events}
        dateClick={handleDateClick}
        height={450}
      />
    </div>
  )
}
