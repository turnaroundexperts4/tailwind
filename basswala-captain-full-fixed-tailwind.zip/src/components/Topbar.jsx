
import React from 'react'

export default function Topbar({ title, actions }){
  return (
    <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800">
      <h2 className="text-xl font-semibold">{title}</h2>
      <div className="flex items-center gap-3">
        {actions}
      </div>
    </div>
  )
}
