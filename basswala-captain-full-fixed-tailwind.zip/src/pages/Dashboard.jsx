import React from 'react'
export default function Dashboard(){ return <div className='p-6'><h2 className='text-xl'>Dashboard Page (Demo)</h2></div> }