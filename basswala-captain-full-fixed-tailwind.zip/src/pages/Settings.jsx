import React from 'react'
export default function Settings(){ return <div className='p-6'><h2 className='text-xl'>Settings Page (Demo)</h2></div> }