import React from 'react'
export default function Chatbot(){ return <div className='p-6'><h2 className='text-xl'>Chatbot Page (Demo)</h2></div> }