import React from 'react'
export default function OtpVerify(){ return <div className='p-6'><h2 className='text-xl'>OtpVerify Page (Demo)</h2></div> }