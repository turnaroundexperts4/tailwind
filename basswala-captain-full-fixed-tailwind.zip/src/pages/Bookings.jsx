import React from 'react'
export default function Bookings(){ return <div className='p-6'><h2 className='text-xl'>Bookings Page (Demo)</h2></div> }