import React from 'react'
export default function Subscribe(){ return <div className='p-6'><h2 className='text-xl'>Subscribe Page (Demo)</h2></div> }