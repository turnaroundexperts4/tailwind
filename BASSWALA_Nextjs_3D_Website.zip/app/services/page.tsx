
import { motion } from 'framer-motion'

const services = ['DJ Services','Sound Systems','Lighting & Visuals','Technical Support','Event Management']

export default function Services() {
  return (
    <section className="p-12 grid md:grid-cols-3 gap-8">
      {services.map(s => (
        <motion.div key={s} whileHover={{scale:1.05}} className="p-6 border border-purple-500 rounded-xl neon-glow">
          {s}
        </motion.div>
      ))}
    </section>
  )
}
