
import './globals.css'

export const metadata = {
  title: 'BASSWALA – Feel the Bass',
  description: 'Premium DJ Equipment & Agency Partner Platform'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-black text-white overflow-x-hidden">{children}</body>
    </html>
  )
}
