
'use client'
import { useForm } from 'react-hook-form'

export default function Partner() {
  const { register, handleSubmit } = useForm()

  return (
    <form onSubmit={handleSubmit(console.log)} className="max-w-xl mx-auto p-8">
      <h2 className="text-3xl mb-6">Agency Registration</h2>
      <input {...register('agency')} placeholder="Agency Name" className="input" />
      <input {...register('owner')} placeholder="Owner Name" className="input" />
      <input {...register('email')} placeholder="Email" className="input" />
      <button className="neon-btn mt-6">Submit</button>
    </form>
  )
}
