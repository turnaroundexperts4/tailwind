
'use client'
import dynamic from 'next/dynamic'
import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'

const DJScene = dynamic(() => import('../components/3d/DJScene'), { ssr: false })

export default function Home() {
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    setIsMobile(window.innerWidth < 768)
  }, [])

  return (
    <main className="min-h-screen relative">
      {!isMobile && <DJScene />}
      {isMobile && <div className="absolute inset-0 bg-gradient-to-b from-purple-900 to-black" />}

      <section className="relative z-10 flex flex-col items-center justify-center min-h-screen text-center">
        <motion.h1 initial={{opacity:0,y:40}} animate={{opacity:1,y:0}} className="text-6xl font-bold text-glow">
          FEEL THE BASS.
        </motion.h1>
        <p className="mt-4 text-xl text-cyan-400">India’s Premium DJ Partner Network</p>
        <div className="mt-8 flex gap-6">
          <a href="/partner" className="neon-btn">Partner With Us</a>
          <a href="/services" className="neon-outline">Explore</a>
        </div>
      </section>
    </main>
  )
}
