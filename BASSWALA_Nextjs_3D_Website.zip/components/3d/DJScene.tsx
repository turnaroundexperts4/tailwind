
'use client'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Float } from '@react-three/drei'

export default function DJScene() {
  return (
    <Canvas className="absolute inset-0" camera={{ position: [0, 2, 6] }}>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5,5,5]} intensity={1.2} />
      <Float speed={2} rotationIntensity={1.5}>
        <mesh>
          <boxGeometry args={[2,1,1]} />
          <meshStandardMaterial color="#bf00ff" emissive="#00ffff" />
        </mesh>
      </Float>
      <OrbitControls enableZoom={false} />
    </Canvas>
  )
}
